package exception;


/**
 * Base exception for the project
 * @author Victor
 *
 */
public class ShipException extends Exception {

	private static final long serialVersionUID = 3195467007985078054L;

}
