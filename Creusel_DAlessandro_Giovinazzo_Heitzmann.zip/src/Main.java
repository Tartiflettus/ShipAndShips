import model.Model;
import view.FieldView;

public class Main {

	public Main() {
		Model model = new Model();
		FieldView fw = new FieldView(model);
		
		
		
		
		
		
	}
	
	public static void main(String[] args) {
		new Main();
	}
	
}
