package exception;

public class NotPlaceableException extends ShipException  {

	private static final long serialVersionUID = -6145446446567922098L;

}
